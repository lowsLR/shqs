<template>
	<view class="nothing u-f-ajc animated fadeIn">
		<image src="../../static/common/nothing.png" 
		mode="widthFix"></image>
	</view>
</template>

<script>
</script>

<style>
	.nothing{
		background: #FFFFFF;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
	}
	.nothing image{
		width: 50%;
	}
</style>
