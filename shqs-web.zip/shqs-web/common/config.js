// 配置信息
export default {
	// api请求前缀
	webUrl: 'https://www.vfor.top/api/v1',
	// webUrl:'https://ceshi2.dishait.cn/api/v1',
	// websocket地址
	websocketUrl: "wss://www.vfor.top/wss",
	// websocketUrl:"wss://ceshi2.dishait.cn/wss",
	// 消息提示tabbar索引
	TabbarIndex: 2
}
