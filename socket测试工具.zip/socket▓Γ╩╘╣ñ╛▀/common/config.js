export default {
	// 请求地址前缀
	webUrl: 'https://www.vfor.top/api/v1',
	// websocket链接
	socketUrl: 'wss://www.vfor.top/wss',
	// 当前用户token
	token: 'a2b3321a53b27dc656490d9de65b4f8c7e85bcd0',
	// 可选当前用户token
	tokenArr: {
		'14': 'a2b3321a53b27dc656490d9de65b4f8c7e85bcd0',
		'15': 'c7d445550fee3ae55198f43d91a944271611cdd2',
	},
	// 可选聊天对象用户id
	userArr: [
		'14',
		'15',
	]
}
