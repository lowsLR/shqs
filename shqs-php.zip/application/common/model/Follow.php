<?php

namespace app\common\model;

use think\Model;

class Follow extends Model
{
    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
}
